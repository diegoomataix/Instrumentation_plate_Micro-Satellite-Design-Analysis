El modelo de Patran ha sido importado desde un fichero .bdf, ya que se ha empleado este tipo de 
ficheros para conseguir iterar más rápido. Al hacer esto el programa une las dos propiedades de 
masa puntual en una sola, a la que le aplica las transformaciones necesarias y cambia los nombres 
de algunas propiedades, como las secciones de los rigidizadores.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Se puede acceder a todos los archivos de esta práctica, en el repositorio:

https://github.com/diegoomataix/Micro-Satellite-Design-Analysis